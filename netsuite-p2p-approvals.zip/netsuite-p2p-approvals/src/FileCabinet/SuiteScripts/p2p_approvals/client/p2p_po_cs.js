/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope Public
 * @description Client script for PO approval actions
 */
define(['N/currentRecord', 'N/url', 'N/https', 'N/ui/dialog', 'N/ui/message'],
function(currentRecord, url, https, dialog, message) {

    function pageInit(context) {
        // Initialize page
    }

    /**
     * Submit PO for approval
     */
    function submitForApproval(recordId) {
        dialog.confirm({
            title: 'Submit for Approval',
            message: 'Are you sure you want to submit this Purchase Order for approval?'
        }).then(function(result) {
            if (result) {
                showProcessingMessage('Submitting for approval...');
                
                const suiteletUrl = url.resolveScript({
                    scriptId: 'customscript_p2p_approval_action_sl',
                    deploymentId: 'customdeploy_p2p_approval_action',
                    params: {
                        action: 'submit',
                        recordType: 'purchaseorder',
                        recordId: recordId
                    }
                });

                https.get.promise({
                    url: suiteletUrl
                }).then(function(response) {
                    const result = JSON.parse(response.body);
                    if (result.success) {
                        showSuccessMessage('Purchase Order submitted for approval');
                        window.location.reload();
                    } else {
                        showErrorMessage('Error: ' + result.error);
                    }
                }).catch(function(error) {
                    showErrorMessage('Error submitting for approval: ' + error.message);
                });
            }
        });
    }

    /**
     * Approve the record
     */
    function approveRecord(recordId) {
        dialog.create({
            title: 'Approve Purchase Order',
            message: 'Add an optional comment:',
            buttons: [
                { label: 'Approve', value: 'approve' },
                { label: 'Cancel', value: 'cancel' }
            ]
        }).then(function(result) {
            if (result === 'approve') {
                promptForComment('Approve', function(comment) {
                    processApproval(recordId, 'approve', comment);
                });
            }
        });
    }

    /**
     * Reject the record
     */
    function rejectRecord(recordId) {
        promptForComment('Reject (comment required)', function(comment) {
            if (!comment || comment.trim() === '') {
                showErrorMessage('A comment is required when rejecting');
                return;
            }
            processApproval(recordId, 'reject', comment);
        }, true);
    }

    /**
     * Resubmit after rejection
     */
    function resubmitForApproval(recordId) {
        dialog.confirm({
            title: 'Resubmit for Approval',
            message: 'Are you sure you want to resubmit this Purchase Order for approval?'
        }).then(function(result) {
            if (result) {
                showProcessingMessage('Resubmitting for approval...');
                
                const suiteletUrl = url.resolveScript({
                    scriptId: 'customscript_p2p_approval_action_sl',
                    deploymentId: 'customdeploy_p2p_approval_action',
                    params: {
                        action: 'resubmit',
                        recordType: 'purchaseorder',
                        recordId: recordId
                    }
                });

                https.get.promise({
                    url: suiteletUrl
                }).then(function(response) {
                    const result = JSON.parse(response.body);
                    if (result.success) {
                        showSuccessMessage('Purchase Order resubmitted for approval');
                        window.location.reload();
                    } else {
                        showErrorMessage('Error: ' + result.error);
                    }
                }).catch(function(error) {
                    showErrorMessage('Error resubmitting: ' + error.message);
                });
            }
        });
    }

    /**
     * Process approval/rejection
     */
    function processApproval(recordId, action, comment) {
        showProcessingMessage('Processing ' + action + '...');
        
        const suiteletUrl = url.resolveScript({
            scriptId: 'customscript_p2p_approval_action_sl',
            deploymentId: 'customdeploy_p2p_approval_action',
            params: {
                action: action,
                recordType: 'purchaseorder',
                recordId: recordId,
                comment: comment || ''
            }
        });

        https.get.promise({
            url: suiteletUrl
        }).then(function(response) {
            const result = JSON.parse(response.body);
            if (result.success) {
                const msg = action === 'approve' ? 'Purchase Order approved' : 'Purchase Order rejected';
                showSuccessMessage(msg);
                window.location.reload();
            } else {
                showErrorMessage('Error: ' + result.error);
            }
        }).catch(function(error) {
            showErrorMessage('Error processing approval: ' + error.message);
        });
    }

    /**
     * Prompt user for comment
     */
    function promptForComment(actionLabel, callback, required) {
        const comment = prompt(actionLabel + '\n\nEnter comment' + (required ? ' (required):' : ' (optional):'));
        
        if (comment === null) {
            return; // User cancelled
        }
        
        callback(comment);
    }

    /**
     * Show processing message
     */
    function showProcessingMessage(text) {
        message.create({
            title: 'Processing',
            message: text,
            type: message.Type.INFORMATION
        }).show({ duration: 0 });
    }

    /**
     * Show success message
     */
    function showSuccessMessage(text) {
        message.create({
            title: 'Success',
            message: text,
            type: message.Type.CONFIRMATION
        }).show({ duration: 5000 });
    }

    /**
     * Show error message
     */
    function showErrorMessage(text) {
        message.create({
            title: 'Error',
            message: text,
            type: message.Type.ERROR
        }).show({ duration: 10000 });
    }

    return {
        pageInit: pageInit,
        submitForApproval: submitForApproval,
        approveRecord: approveRecord,
        rejectRecord: rejectRecord,
        resubmitForApproval: resubmitForApproval
    };
});
