/**
 * @NApiVersion 2.1
 * @NScriptType ClientScript
 * @NModuleScope Public
 * @description Client script for Vendor Bill approval actions with matching
 */
define(['N/currentRecord', 'N/url', 'N/https', 'N/ui/dialog', 'N/ui/message'],
function(currentRecord, url, https, dialog, message) {

    function pageInit(context) {
        // Initialize page
    }

    /**
     * Submit VB for approval
     */
    function submitForApproval(recordId) {
        dialog.confirm({
            title: 'Submit for Approval',
            message: 'This will perform 3-way matching and submit for approval. Continue?'
        }).then(function(result) {
            if (result) {
                showProcessingMessage('Running 3-way match and submitting...');
                
                const suiteletUrl = url.resolveScript({
                    scriptId: 'customscript_p2p_approval_action_sl',
                    deploymentId: 'customdeploy_p2p_approval_action',
                    params: {
                        action: 'submit',
                        recordType: 'vendorbill',
                        recordId: recordId
                    }
                });

                https.get.promise({
                    url: suiteletUrl
                }).then(function(response) {
                    const result = JSON.parse(response.body);
                    if (result.success) {
                        let msg = 'Vendor Bill submitted for approval';
                        if (result.matchStatus === 'FAIL') {
                            msg += ' (with matching exceptions)';
                        }
                        showSuccessMessage(msg);
                        window.location.reload();
                    } else {
                        showErrorMessage('Error: ' + result.error);
                    }
                }).catch(function(error) {
                    showErrorMessage('Error submitting for approval: ' + error.message);
                });
            }
        });
    }

    /**
     * Re-check matching without submitting
     */
    function recheckMatching(recordId) {
        showProcessingMessage('Re-checking 3-way match...');
        
        const suiteletUrl = url.resolveScript({
            scriptId: 'customscript_p2p_approval_action_sl',
            deploymentId: 'customdeploy_p2p_approval_action',
            params: {
                action: 'recheck_match',
                recordType: 'vendorbill',
                recordId: recordId
            }
        });

        https.get.promise({
            url: suiteletUrl
        }).then(function(response) {
            const result = JSON.parse(response.body);
            if (result.success) {
                const status = result.matchStatus === 'PASS' ? 'PASSED' : 'FAILED';
                let msg = 'Matching check ' + status;
                if (result.exceptions && result.exceptions.length > 0) {
                    msg += ': ' + result.exceptions.join(', ');
                }
                if (result.matchStatus === 'PASS') {
                    showSuccessMessage(msg);
                } else {
                    showWarningMessage(msg);
                }
                window.location.reload();
            } else {
                showErrorMessage('Error: ' + result.error);
            }
        }).catch(function(error) {
            showErrorMessage('Error checking match: ' + error.message);
        });
    }

    /**
     * Approve the record
     */
    function approveRecord(recordId) {
        promptForComment('Approve Vendor Bill', function(comment) {
            processApproval(recordId, 'approve', comment);
        });
    }

    /**
     * Reject the record
     */
    function rejectRecord(recordId) {
        promptForComment('Reject Vendor Bill (comment required)', function(comment) {
            if (!comment || comment.trim() === '') {
                showErrorMessage('A comment is required when rejecting');
                return;
            }
            processApproval(recordId, 'reject', comment);
        }, true);
    }

    /**
     * Approve with exception override
     */
    function approveWithException(recordId) {
        dialog.create({
            title: 'Approve with Exception',
            message: 'You are approving this Vendor Bill despite matching exceptions.\n\nThis action will be logged. Please provide a justification:',
            buttons: [
                { label: 'Approve with Exception', value: 'approve' },
                { label: 'Cancel', value: 'cancel' }
            ]
        }).then(function(result) {
            if (result === 'approve') {
                promptForComment('Exception Justification (required)', function(comment) {
                    if (!comment || comment.trim() === '') {
                        showErrorMessage('A justification is required for exception approval');
                        return;
                    }
                    processApproval(recordId, 'approve_exception', comment);
                }, true);
            }
        });
    }

    /**
     * Resubmit after rejection
     */
    function resubmitForApproval(recordId) {
        dialog.confirm({
            title: 'Resubmit for Approval',
            message: 'This will re-run 3-way matching and resubmit for approval. Continue?'
        }).then(function(result) {
            if (result) {
                showProcessingMessage('Resubmitting for approval...');
                
                const suiteletUrl = url.resolveScript({
                    scriptId: 'customscript_p2p_approval_action_sl',
                    deploymentId: 'customdeploy_p2p_approval_action',
                    params: {
                        action: 'resubmit',
                        recordType: 'vendorbill',
                        recordId: recordId
                    }
                });

                https.get.promise({
                    url: suiteletUrl
                }).then(function(response) {
                    const result = JSON.parse(response.body);
                    if (result.success) {
                        showSuccessMessage('Vendor Bill resubmitted for approval');
                        window.location.reload();
                    } else {
                        showErrorMessage('Error: ' + result.error);
                    }
                }).catch(function(error) {
                    showErrorMessage('Error resubmitting: ' + error.message);
                });
            }
        });
    }

    /**
     * Process approval/rejection
     */
    function processApproval(recordId, action, comment) {
        showProcessingMessage('Processing...');
        
        const suiteletUrl = url.resolveScript({
            scriptId: 'customscript_p2p_approval_action_sl',
            deploymentId: 'customdeploy_p2p_approval_action',
            params: {
                action: action,
                recordType: 'vendorbill',
                recordId: recordId,
                comment: comment || ''
            }
        });

        https.get.promise({
            url: suiteletUrl
        }).then(function(response) {
            const result = JSON.parse(response.body);
            if (result.success) {
                let msg;
                switch (action) {
                    case 'approve':
                        msg = 'Vendor Bill approved';
                        break;
                    case 'approve_exception':
                        msg = 'Vendor Bill approved with exception';
                        break;
                    case 'reject':
                        msg = 'Vendor Bill rejected';
                        break;
                    default:
                        msg = 'Action completed';
                }
                showSuccessMessage(msg);
                window.location.reload();
            } else {
                showErrorMessage('Error: ' + result.error);
            }
        }).catch(function(error) {
            showErrorMessage('Error processing: ' + error.message);
        });
    }

    /**
     * Prompt user for comment
     */
    function promptForComment(actionLabel, callback, required) {
        const comment = prompt(actionLabel + '\n\nEnter comment' + (required ? ' (required):' : ' (optional):'));
        
        if (comment === null) {
            return; // User cancelled
        }
        
        callback(comment);
    }

    /**
     * Show processing message
     */
    function showProcessingMessage(text) {
        message.create({
            title: 'Processing',
            message: text,
            type: message.Type.INFORMATION
        }).show({ duration: 0 });
    }

    /**
     * Show success message
     */
    function showSuccessMessage(text) {
        message.create({
            title: 'Success',
            message: text,
            type: message.Type.CONFIRMATION
        }).show({ duration: 5000 });
    }

    /**
     * Show warning message
     */
    function showWarningMessage(text) {
        message.create({
            title: 'Warning',
            message: text,
            type: message.Type.WARNING
        }).show({ duration: 10000 });
    }

    /**
     * Show error message
     */
    function showErrorMessage(text) {
        message.create({
            title: 'Error',
            message: text,
            type: message.Type.ERROR
        }).show({ duration: 10000 });
    }

    return {
        pageInit: pageInit,
        submitForApproval: submitForApproval,
        recheckMatching: recheckMatching,
        approveRecord: approveRecord,
        rejectRecord: rejectRecord,
        approveWithException: approveWithException,
        resubmitForApproval: resubmitForApproval
    };
});
