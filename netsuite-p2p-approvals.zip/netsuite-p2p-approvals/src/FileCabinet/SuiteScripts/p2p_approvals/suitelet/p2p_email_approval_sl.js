/**
 * @NApiVersion 2.1
 * @NScriptType Suitelet
 * @NModuleScope Public
 * @description Handles email approval links - validates token and processes approval
 */
define([
    'N/ui/serverWidget',
    'N/search',
    'N/record',
    '../lib/p2p_token_manager',
    '../lib/p2p_approval_engine',
    '../constants/p2p_constants'
], function(serverWidget, search, record, tokenManager, approvalEngine, constants) {

    const { APPROVAL_ACTION, APPROVAL_METHOD, TRANSACTION_TYPES } = constants;

    function onRequest(context) {
        const request = context.request;
        const response = context.response;
        
        const token = request.parameters.token;
        const action = request.parameters.action;

        // Validate token
        const validation = tokenManager.validateToken(token);

        if (!validation.valid) {
            return renderErrorPage(response, validation.error, validation.expired);
        }

        if (request.method === 'GET') {
            // Show confirmation page
            return renderConfirmationPage(response, validation, action, token);
        }

        if (request.method === 'POST') {
            // Process the approval
            return processEmailApproval(context, validation, action);
        }
    }

    /**
     * Render confirmation page
     */
    function renderConfirmationPage(response, validation, action, token) {
        const tranData = getTransactionDetails(validation.transactionType, validation.transactionId);
        const typeLabel = validation.transactionType === TRANSACTION_TYPES.PURCHASE_ORDER 
            ? 'Purchase Order' : 'Vendor Bill';
        const actionLabel = action === 'approve' ? 'Approve' : 'Reject';
        const actionColor = action === 'approve' ? '#28a745' : '#dc3545';

        const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${actionLabel} ${typeLabel}</title>
    <style>
        * { box-sizing: border-box; }
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: ${actionColor};
            color: white;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
        }
        .content {
            padding: 20px;
        }
        .details {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .detail-row:last-child {
            border-bottom: none;
        }
        .detail-label {
            font-weight: bold;
            color: #555;
        }
        .detail-value {
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            resize: vertical;
        }
        .buttons {
            display: flex;
            gap: 10px;
        }
        .btn {
            flex: 1;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
        }
        .btn-primary {
            background: ${actionColor};
            color: white;
        }
        .btn-secondary {
            background: #6c757d;
            color: white;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .warning {
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>${actionLabel} ${typeLabel}</h1>
        </div>
        <div class="content">
            <div class="details">
                <div class="detail-row">
                    <span class="detail-label">Document</span>
                    <span class="detail-value">${tranData.tranId || 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Vendor</span>
                    <span class="detail-value">${tranData.vendor || 'N/A'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Amount</span>
                    <span class="detail-value">$${tranData.amount ? tranData.amount.toFixed(2) : '0.00'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Date</span>
                    <span class="detail-value">${tranData.tranDate || 'N/A'}</span>
                </div>
            </div>

            ${action === 'reject' ? `
            <div class="warning">
                ⚠️ A comment is required when rejecting.
            </div>
            ` : ''}

            <form method="POST">
                <input type="hidden" name="token" value="${token}">
                <input type="hidden" name="action" value="${action}">
                
                <div class="form-group">
                    <label for="comment">Comment ${action === 'reject' ? '(required)' : '(optional)'}</label>
                    <textarea id="comment" name="comment" rows="3" 
                        placeholder="Enter your comment here..."
                        ${action === 'reject' ? 'required' : ''}></textarea>
                </div>

                <div class="buttons">
                    <button type="submit" class="btn btn-primary">
                        Confirm ${actionLabel}
                    </button>
                    <button type="button" class="btn btn-secondary" onclick="window.close()">
                        Cancel
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
        `;

        response.write(html);
    }

    /**
     * Process the email approval
     */
    function processEmailApproval(context, validation, action) {
        const request = context.request;
        const response = context.response;
        
        const comment = request.parameters.comment;
        const ipAddress = request.clientIpAddress;

        // Validate rejection has comment
        if (action === 'reject' && (!comment || comment.trim() === '')) {
            return renderErrorPage(response, 'A comment is required when rejecting');
        }

        try {
            const approvalAction = action === 'approve' 
                ? APPROVAL_ACTION.APPROVE 
                : APPROVAL_ACTION.REJECT;

            const result = approvalEngine.processApproval({
                taskId: validation.taskId,
                action: approvalAction,
                comment: comment,
                method: APPROVAL_METHOD.EMAIL,
                ipAddress: ipAddress,
                actingUserId: validation.actingApprover || validation.approver
            });

            if (result.success) {
                // Invalidate the token
                tokenManager.invalidateToken(validation.taskId);
                
                return renderSuccessPage(response, action, result);
            } else {
                return renderErrorPage(response, result.error);
            }

        } catch (e) {
            log.error('Error processing email approval', e);
            return renderErrorPage(response, 'An error occurred: ' + e.message);
        }
    }

    /**
     * Render success page
     */
    function renderSuccessPage(response, action, result) {
        const actionLabel = action === 'approve' ? 'Approved' : 'Rejected';
        const actionColor = action === 'approve' ? '#28a745' : '#dc3545';
        const icon = action === 'approve' ? '✓' : '✗';

        const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Action Complete</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 40px;
        }
        .icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: ${actionColor};
            color: white;
            font-size: 40px;
            line-height: 80px;
            margin: 0 auto 20px;
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        p {
            color: #666;
        }
        .close-btn {
            margin-top: 20px;
            padding: 10px 30px;
            background: #6c757d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">${icon}</div>
        <h1>${actionLabel}</h1>
        <p>Your action has been recorded successfully.</p>
        <p>${result.message || ''}</p>
        <button class="close-btn" onclick="window.close()">Close Window</button>
    </div>
</body>
</html>
        `;

        response.write(html);
    }

    /**
     * Render error page
     */
    function renderErrorPage(response, errorMessage, isExpired) {
        const html = `
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Error</title>
    <style>
        body { 
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 400px;
            margin: 50px auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 40px;
        }
        .icon {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: #dc3545;
            color: white;
            font-size: 40px;
            line-height: 80px;
            margin: 0 auto 20px;
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        p {
            color: #666;
        }
        .suggestion {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">!</div>
        <h1>Unable to Process</h1>
        <p>${errorMessage}</p>
        ${isExpired ? `
        <div class="suggestion">
            <strong>Token Expired</strong><br>
            Please log in to NetSuite to complete this approval, or request a new approval email.
        </div>
        ` : ''}
    </div>
</body>
</html>
        `;

        response.write(html);
    }

    /**
     * Get transaction details for display
     */
    function getTransactionDetails(tranType, tranId) {
        try {
            const recordType = tranType === TRANSACTION_TYPES.PURCHASE_ORDER 
                ? 'purchaseorder' : 'vendorbill';
            
            const fields = search.lookupFields({
                type: recordType,
                id: tranId,
                columns: ['tranid', 'entity', 'total', 'trandate', 'memo']
            });

            return {
                tranId: fields.tranid,
                vendor: fields.entity[0]?.text,
                amount: parseFloat(fields.total) || 0,
                tranDate: fields.trandate,
                memo: fields.memo
            };
        } catch (e) {
            log.error('Error getting transaction details', e);
            return {};
        }
    }

    return { onRequest };
});
