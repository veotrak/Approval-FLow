/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * @NModuleScope Public
 * @description Sends reminder notifications for pending approvals
 * Schedule: Every 4 hours
 */
define([
    'N/search',
    'N/record',
    'N/runtime',
    '../lib/p2p_notification_manager',
    '../constants/p2p_constants'
], function(search, record, runtime, notificationManager, constants) {

    const { RECORD_TYPES, TASK_FIELDS, TASK_STATUS, CONFIG } = constants;

    function execute(context) {
        log.audit('P2P Reminder Script Started', new Date());

        const now = new Date();
        let reminderssSent = 0;
        let errors = 0;

        try {
            // Find tasks needing first reminder (24+ hours, reminder_count = 0)
            const firstReminderTasks = findTasksForReminder(24, 0);
            log.debug('Tasks for first reminder', firstReminderTasks.length);

            firstReminderTasks.forEach(task => {
                if (checkGovernance()) {
                    try {
                        const result = notificationManager.sendReminder({
                            taskId: task.id,
                            reminderNumber: 1
                        });
                        if (result.success) {
                            reminderssSent++;
                        } else {
                            errors++;
                            log.error('Failed to send first reminder', { taskId: task.id, error: result.error });
                        }
                    } catch (e) {
                        errors++;
                        log.error('Error sending first reminder', { taskId: task.id, error: e });
                    }
                }
            });

            // Find tasks needing second reminder (48+ hours, reminder_count = 1)
            const secondReminderTasks = findTasksForReminder(48, 1);
            log.debug('Tasks for second reminder', secondReminderTasks.length);

            secondReminderTasks.forEach(task => {
                if (checkGovernance()) {
                    try {
                        const result = notificationManager.sendReminder({
                            taskId: task.id,
                            reminderNumber: 2
                        });
                        if (result.success) {
                            reminderssSent++;
                        } else {
                            errors++;
                            log.error('Failed to send second reminder', { taskId: task.id, error: result.error });
                        }
                    } catch (e) {
                        errors++;
                        log.error('Error sending second reminder', { taskId: task.id, error: e });
                    }
                }
            });

            log.audit('P2P Reminder Script Completed', {
                remindersSent: reminderssSent,
                errors: errors
            });

        } catch (e) {
            log.error('P2P Reminder Script Error', e);
        }
    }

    /**
     * Find tasks that need reminders
     * @param {number} hoursOld - Minimum age in hours
     * @param {number} currentReminderCount - Current reminder count (send if count equals this)
     */
    function findTasksForReminder(hoursOld, currentReminderCount) {
        const cutoffTime = new Date();
        cutoffTime.setHours(cutoffTime.getHours() - hoursOld);

        const taskSearch = search.create({
            type: RECORD_TYPES.APPROVAL_TASK,
            filters: [
                [TASK_FIELDS.STATUS, 'anyof', TASK_STATUS.PENDING],
                'AND',
                [TASK_FIELDS.CREATED, 'before', cutoffTime],
                'AND',
                [TASK_FIELDS.REMINDER_COUNT, 'equalto', currentReminderCount]
            ],
            columns: [
                search.createColumn({ name: 'internalid' }),
                search.createColumn({ name: TASK_FIELDS.TRAN_TYPE }),
                search.createColumn({ name: TASK_FIELDS.TRAN_ID }),
                search.createColumn({ name: TASK_FIELDS.APPROVER }),
                search.createColumn({ name: TASK_FIELDS.ACTING_APPROVER }),
                search.createColumn({ name: TASK_FIELDS.CREATED })
            ]
        });

        const tasks = [];
        
        taskSearch.run().each(function(result) {
            tasks.push({
                id: result.getValue('internalid'),
                tranType: result.getValue(TASK_FIELDS.TRAN_TYPE),
                tranId: result.getValue(TASK_FIELDS.TRAN_ID),
                approver: result.getValue(TASK_FIELDS.APPROVER),
                actingApprover: result.getValue(TASK_FIELDS.ACTING_APPROVER),
                created: result.getValue(TASK_FIELDS.CREATED)
            });
            return tasks.length < 200; // Limit batch size
        });

        return tasks;
    }

    /**
     * Check remaining governance units
     */
    function checkGovernance() {
        const remaining = runtime.getCurrentScript().getRemainingUsage();
        return remaining > 100;
    }

    return { execute };
});
