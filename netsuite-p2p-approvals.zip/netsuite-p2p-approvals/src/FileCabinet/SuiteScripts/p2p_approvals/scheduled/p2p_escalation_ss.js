/**
 * @NApiVersion 2.1
 * @NScriptType ScheduledScript
 * @NModuleScope Public
 * @description Escalates overdue approvals to manager
 * Schedule: Every 4 hours
 */
define([
    'N/search',
    'N/record',
    'N/runtime',
    '../lib/p2p_notification_manager',
    '../lib/p2p_history_logger',
    '../constants/p2p_constants'
], function(search, record, runtime, notificationManager, historyLogger, constants) {

    const { RECORD_TYPES, TASK_FIELDS, TASK_STATUS, APPROVAL_ACTION, CONFIG } = constants;

    function execute(context) {
        log.audit('P2P Escalation Script Started', new Date());

        let escalations = 0;
        let errors = 0;

        try {
            // Find tasks needing escalation (72+ hours, not yet escalated)
            const tasksToEscalate = findTasksForEscalation();
            log.debug('Tasks to escalate', tasksToEscalate.length);

            tasksToEscalate.forEach(task => {
                if (checkGovernance()) {
                    try {
                        const result = escalateTask(task);
                        if (result.success) {
                            escalations++;
                        } else {
                            errors++;
                            log.error('Failed to escalate task', { taskId: task.id, error: result.error });
                        }
                    } catch (e) {
                        errors++;
                        log.error('Error escalating task', { taskId: task.id, error: e });
                    }
                }
            });

            log.audit('P2P Escalation Script Completed', {
                escalations: escalations,
                errors: errors
            });

        } catch (e) {
            log.error('P2P Escalation Script Error', e);
        }
    }

    /**
     * Find tasks that need escalation
     */
    function findTasksForEscalation() {
        const cutoffTime = new Date();
        cutoffTime.setHours(cutoffTime.getHours() - CONFIG.ESCALATION_HOURS);

        const taskSearch = search.create({
            type: RECORD_TYPES.APPROVAL_TASK,
            filters: [
                [TASK_FIELDS.STATUS, 'anyof', TASK_STATUS.PENDING],
                'AND',
                [TASK_FIELDS.CREATED, 'before', cutoffTime],
                'AND',
                [TASK_FIELDS.ESCALATED, 'is', 'F']
            ],
            columns: [
                search.createColumn({ name: 'internalid' }),
                search.createColumn({ name: TASK_FIELDS.TRAN_TYPE }),
                search.createColumn({ name: TASK_FIELDS.TRAN_ID }),
                search.createColumn({ name: TASK_FIELDS.APPROVER }),
                search.createColumn({ name: TASK_FIELDS.ACTING_APPROVER }),
                search.createColumn({ name: TASK_FIELDS.SEQUENCE }),
                search.createColumn({ name: TASK_FIELDS.RULE }),
                search.createColumn({ name: TASK_FIELDS.CREATED })
            ]
        });

        const tasks = [];
        
        taskSearch.run().each(function(result) {
            tasks.push({
                id: result.getValue('internalid'),
                tranType: result.getValue(TASK_FIELDS.TRAN_TYPE),
                tranId: result.getValue(TASK_FIELDS.TRAN_ID),
                approver: result.getValue(TASK_FIELDS.APPROVER),
                actingApprover: result.getValue(TASK_FIELDS.ACTING_APPROVER),
                sequence: result.getValue(TASK_FIELDS.SEQUENCE),
                ruleId: result.getValue(TASK_FIELDS.RULE),
                created: result.getValue(TASK_FIELDS.CREATED)
            });
            return tasks.length < 100; // Limit batch size
        });

        return tasks;
    }

    /**
     * Escalate a task to approver's manager
     */
    function escalateTask(task) {
        try {
            // Get the current approver (might be delegate)
            const currentApprover = task.actingApprover || task.approver;
            
            // Get approver's manager
            const manager = getEmployeeManager(currentApprover);
            
            if (!manager) {
                log.warn('No manager found for escalation', { approver: currentApprover });
                // Fall back to CFO role
                const fallbackApprover = getFallbackApprover();
                if (!fallbackApprover) {
                    return { success: false, error: 'No escalation target found' };
                }
                manager = fallbackApprover;
            }

            // Get manager's email
            const managerEmail = getEmployeeEmail(manager.id);
            if (!managerEmail) {
                return { success: false, error: 'No email for escalation target' };
            }

            // Send escalation notification
            notificationManager.sendEscalation({
                taskId: task.id,
                escalationTargetId: manager.id,
                escalationTargetEmail: managerEmail
            });

            // Log escalation in history
            historyLogger.logAction({
                transactionType: task.tranType,
                transactionId: task.tranId,
                stepSequence: task.sequence,
                approver: currentApprover,
                actingApprover: manager.id,
                action: APPROVAL_ACTION.ESCALATE,
                comment: `Escalated to ${manager.name} after ${CONFIG.ESCALATION_HOURS} hours`,
                method: constants.APPROVAL_METHOD.API
            });

            // Mark task as escalated (manager can now also act on it)
            record.submitFields({
                type: RECORD_TYPES.APPROVAL_TASK,
                id: task.id,
                values: {
                    [TASK_FIELDS.ESCALATED]: true
                }
            });

            // Optionally create a new task for the manager
            createEscalationTask(task, manager.id);

            return { success: true };

        } catch (e) {
            log.error('Error in escalateTask', e);
            return { success: false, error: e.message };
        }
    }

    /**
     * Create a new approval task for the escalation target
     */
    function createEscalationTask(originalTask, managerId) {
        try {
            const tokenManager = require('../lib/p2p_token_manager');
            const token = tokenManager.generateToken();
            const tokenExpiry = new Date();
            tokenExpiry.setHours(tokenExpiry.getHours() + CONFIG.TOKEN_EXPIRY_HOURS);

            const taskRec = record.create({ type: RECORD_TYPES.APPROVAL_TASK });
            taskRec.setValue({ fieldId: TASK_FIELDS.TRAN_TYPE, value: originalTask.tranType });
            taskRec.setValue({ fieldId: TASK_FIELDS.TRAN_ID, value: originalTask.tranId });
            taskRec.setValue({ fieldId: TASK_FIELDS.RULE, value: originalTask.ruleId });
            taskRec.setValue({ fieldId: TASK_FIELDS.SEQUENCE, value: originalTask.sequence });
            taskRec.setValue({ fieldId: TASK_FIELDS.APPROVER, value: managerId });
            taskRec.setValue({ fieldId: TASK_FIELDS.STATUS, value: TASK_STATUS.PENDING });
            taskRec.setValue({ fieldId: TASK_FIELDS.CREATED, value: new Date() });
            taskRec.setValue({ fieldId: TASK_FIELDS.TOKEN, value: token });
            taskRec.setValue({ fieldId: TASK_FIELDS.TOKEN_EXPIRY, value: tokenExpiry });
            taskRec.setValue({ fieldId: TASK_FIELDS.ESCALATED, value: true });

            const taskId = taskRec.save();
            log.debug('Escalation task created', { taskId, manager: managerId });

            return taskId;

        } catch (e) {
            log.error('Error creating escalation task', e);
            return null;
        }
    }

    /**
     * Get employee's manager
     */
    function getEmployeeManager(employeeId) {
        try {
            const emp = search.lookupFields({
                type: 'employee',
                id: employeeId,
                columns: ['supervisor']
            });

            if (emp.supervisor && emp.supervisor.length > 0) {
                return {
                    id: emp.supervisor[0].value,
                    name: emp.supervisor[0].text
                };
            }
            return null;
        } catch (e) {
            log.error('Error getting employee manager', e);
            return null;
        }
    }

    /**
     * Get fallback approver (CFO)
     */
    function getFallbackApprover() {
        const empSearch = search.create({
            type: 'employee',
            filters: [
                ['role', 'anyof', CONFIG.FALLBACK_APPROVER_ROLE],
                'AND',
                ['isinactive', 'is', 'F']
            ],
            columns: ['internalid', 'entityid']
        });

        const results = empSearch.run().getRange({ start: 0, end: 1 });
        
        if (results.length > 0) {
            return {
                id: results[0].getValue('internalid'),
                name: results[0].getValue('entityid')
            };
        }
        return null;
    }

    /**
     * Get employee email
     */
    function getEmployeeEmail(employeeId) {
        try {
            const emp = search.lookupFields({
                type: 'employee',
                id: employeeId,
                columns: ['email']
            });
            return emp.email;
        } catch (e) {
            return null;
        }
    }

    /**
     * Check remaining governance units
     */
    function checkGovernance() {
        const remaining = runtime.getCurrentScript().getRemainingUsage();
        return remaining > 200;
    }

    return { execute };
});
