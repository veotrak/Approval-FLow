/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope Public
 * @description User Event script for Purchase Order approval workflow
 */
define([
    'N/record',
    'N/runtime',
    'N/ui/serverWidget',
    'N/search',
    '../lib/p2p_approval_engine',
    '../lib/p2p_history_logger',
    '../constants/p2p_constants'
], function(record, runtime, serverWidget, search, approvalEngine, historyLogger, constants) {

    const { APPROVAL_STATUS, BODY_FIELDS, TRANSACTION_TYPES, APPROVAL_ACTION } = constants;

    /**
     * Before Load - Add UI elements and buttons
     */
    function beforeLoad(context) {
        const { type, form, newRecord } = context;

        if (type === context.UserEventType.VIEW || type === context.UserEventType.EDIT) {
            const approvalStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const recordId = newRecord.id;

            // Add approval status field group
            addApprovalStatusGroup(form, newRecord);

            // Add approval history sublist
            addApprovalHistorySublist(form, recordId);

            // Add approval buttons based on status
            if (type === context.UserEventType.VIEW) {
                addApprovalButtons(form, newRecord, approvalStatus);
            }
        }

        if (type === context.UserEventType.CREATE) {
            // Set default status to Draft
            newRecord.setValue({
                fieldId: BODY_FIELDS.APPROVAL_STATUS,
                value: APPROVAL_STATUS.DRAFT
            });
        }
    }

    /**
     * Before Submit - Validate and prepare for approval routing
     */
    function beforeSubmit(context) {
        const { type, newRecord, oldRecord } = context;

        if (type === context.UserEventType.CREATE) {
            // Set initial status
            newRecord.setValue({
                fieldId: BODY_FIELDS.APPROVAL_STATUS,
                value: APPROVAL_STATUS.DRAFT
            });
        }

        if (type === context.UserEventType.EDIT) {
            const oldStatus = oldRecord?.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const newStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const oldAmount = parseFloat(oldRecord?.getValue('total')) || 0;
            const newAmount = parseFloat(newRecord.getValue('total')) || 0;

            // If approved PO is edited with increased amount, require re-approval
            if (oldStatus === APPROVAL_STATUS.APPROVED && newAmount > oldAmount) {
                log.audit('PO amount increased after approval', {
                    id: newRecord.id,
                    oldAmount,
                    newAmount
                });

                // Reset to draft for re-approval
                newRecord.setValue({
                    fieldId: BODY_FIELDS.APPROVAL_STATUS,
                    value: APPROVAL_STATUS.DRAFT
                });
                newRecord.setValue({
                    fieldId: BODY_FIELDS.CURRENT_STEP,
                    value: ''
                });
                newRecord.setValue({
                    fieldId: BODY_FIELDS.CURRENT_APPROVER,
                    value: ''
                });
            }
        }
    }

    /**
     * After Submit - Trigger approval routing
     */
    function afterSubmit(context) {
        const { type, newRecord, oldRecord } = context;
        const recordId = newRecord.id;

        // Handle submission for approval
        if (type === context.UserEventType.CREATE || type === context.UserEventType.EDIT) {
            const approvalStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);

            // Check if this is a submission request (via custom field or button click)
            const submitForApproval = runtime.getCurrentScript().getParameter({
                name: 'custscript_p2p_submit_for_approval'
            });

            // Auto-submit on create if configured, or if explicitly requested
            if (approvalStatus === APPROVAL_STATUS.DRAFT && shouldAutoSubmit(newRecord)) {
                routeForApproval(recordId, newRecord);
            }
        }
    }

    /**
     * Determine if PO should auto-submit for approval
     */
    function shouldAutoSubmit(record) {
        // Check total amount - might skip approval for small amounts
        const total = parseFloat(record.getValue('total')) || 0;
        
        // Auto-submit if amount requires approval
        // Could also check configuration for auto-submit threshold
        return total > 0;
    }

    /**
     * Route PO for approval
     */
    function routeForApproval(recordId, poRecord) {
        try {
            const transactionData = {
                subsidiary: poRecord.getValue('subsidiary'),
                department: poRecord.getValue('department'),
                location: poRecord.getValue('location'),
                amount: parseFloat(poRecord.getValue('total')) || 0,
                currency: poRecord.getValue('currency'),
                vendor: poRecord.getText('entity'),
                vendorId: poRecord.getValue('entity'),
                tranId: poRecord.getValue('tranid'),
                tranDate: poRecord.getValue('trandate'),
                memo: poRecord.getValue('memo')
            };

            const result = approvalEngine.routeForApproval({
                recordType: 'purchaseorder',
                recordId: recordId,
                transactionData: transactionData
            });

            log.audit('PO routed for approval', {
                recordId,
                result
            });

            return result;

        } catch (e) {
            log.error('Error routing PO for approval', e);
            throw e;
        }
    }

    /**
     * Add approval status field group to form
     */
    function addApprovalStatusGroup(form, record) {
        try {
            const statusGroup = form.addFieldGroup({
                id: 'custpage_approval_status_grp',
                label: 'Approval Status'
            });

            // Status display field
            const statusField = form.addField({
                id: 'custpage_approval_status_display',
                type: serverWidget.FieldType.TEXT,
                label: 'Status',
                container: 'custpage_approval_status_grp'
            });
            statusField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            const statusValue = record.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const statusText = constants.APPROVAL_STATUS_TEXT[statusValue] || 'Unknown';
            statusField.defaultValue = statusText;

            // Current step display
            const currentStep = record.getValue(BODY_FIELDS.CURRENT_STEP);
            if (currentStep) {
                const stepField = form.addField({
                    id: 'custpage_current_step_display',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Current Step',
                    container: 'custpage_approval_status_grp'
                });
                stepField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });
                stepField.defaultValue = `Step ${currentStep}`;
            }

            // Current approver display
            const currentApprover = record.getText(BODY_FIELDS.CURRENT_APPROVER);
            if (currentApprover) {
                const approverField = form.addField({
                    id: 'custpage_current_approver_display',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Pending Approver',
                    container: 'custpage_approval_status_grp'
                });
                approverField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });
                approverField.defaultValue = currentApprover;
            }

        } catch (e) {
            log.error('Error adding approval status group', e);
        }
    }

    /**
     * Add approval history sublist
     */
    function addApprovalHistorySublist(form, recordId) {
        try {
            const historySublist = form.addSublist({
                id: 'custpage_approval_history',
                type: serverWidget.SublistType.LIST,
                label: 'Approval History'
            });

            historySublist.addField({
                id: 'custpage_ah_step',
                type: serverWidget.FieldType.TEXT,
                label: 'Step'
            });
            historySublist.addField({
                id: 'custpage_ah_action',
                type: serverWidget.FieldType.TEXT,
                label: 'Action'
            });
            historySublist.addField({
                id: 'custpage_ah_approver',
                type: serverWidget.FieldType.TEXT,
                label: 'By'
            });
            historySublist.addField({
                id: 'custpage_ah_timestamp',
                type: serverWidget.FieldType.TEXT,
                label: 'Date/Time'
            });
            historySublist.addField({
                id: 'custpage_ah_comment',
                type: serverWidget.FieldType.TEXT,
                label: 'Comment'
            });

            // Get history
            const history = historyLogger.getFormattedHistory(
                TRANSACTION_TYPES.PURCHASE_ORDER,
                recordId
            );

            history.forEach((h, index) => {
                historySublist.setSublistValue({
                    id: 'custpage_ah_step',
                    line: index,
                    value: h.step.toString()
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_action',
                    line: index,
                    value: h.action
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_approver',
                    line: index,
                    value: h.approver
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_timestamp',
                    line: index,
                    value: h.timestamp
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_comment',
                    line: index,
                    value: h.comment || ''
                });
            });

        } catch (e) {
            log.error('Error adding approval history sublist', e);
        }
    }

    /**
     * Add approval action buttons
     */
    function addApprovalButtons(form, record, approvalStatus) {
        const currentUser = runtime.getCurrentUser().id;
        const currentApprover = record.getValue(BODY_FIELDS.CURRENT_APPROVER);
        const recordId = record.id;

        try {
            // Submit for Approval button (for Draft status)
            if (approvalStatus === APPROVAL_STATUS.DRAFT) {
                form.addButton({
                    id: 'custpage_submit_approval',
                    label: 'Submit for Approval',
                    functionName: `submitForApproval(${recordId})`
                });
            }

            // Approve/Reject buttons (for current approver)
            if (approvalStatus === APPROVAL_STATUS.PENDING_APPROVAL) {
                // Check if current user is the approver
                const isApprover = isUserApprover(currentUser, recordId);

                if (isApprover) {
                    form.addButton({
                        id: 'custpage_approve',
                        label: 'Approve',
                        functionName: `approveRecord(${recordId})`
                    });

                    form.addButton({
                        id: 'custpage_reject',
                        label: 'Reject',
                        functionName: `rejectRecord(${recordId})`
                    });
                }
            }

            // Resubmit button (for Rejected status)
            if (approvalStatus === APPROVAL_STATUS.REJECTED) {
                const createdBy = record.getValue('createdby');
                if (currentUser == createdBy) {
                    form.addButton({
                        id: 'custpage_resubmit',
                        label: 'Resubmit for Approval',
                        functionName: `resubmitForApproval(${recordId})`
                    });
                }
            }

            // Add client script for button functions
            form.clientScriptModulePath = './p2p_po_cs.js';

        } catch (e) {
            log.error('Error adding approval buttons', e);
        }
    }

    /**
     * Check if user is an approver for this record
     */
    function isUserApprover(userId, recordId) {
        const taskSearch = search.create({
            type: constants.RECORD_TYPES.APPROVAL_TASK,
            filters: [
                [constants.TASK_FIELDS.TRAN_TYPE, 'anyof', TRANSACTION_TYPES.PURCHASE_ORDER],
                'AND',
                [constants.TASK_FIELDS.TRAN_ID, 'equalto', recordId],
                'AND',
                [constants.TASK_FIELDS.STATUS, 'anyof', constants.TASK_STATUS.PENDING],
                'AND',
                [
                    [constants.TASK_FIELDS.APPROVER, 'anyof', userId],
                    'OR',
                    [constants.TASK_FIELDS.ACTING_APPROVER, 'anyof', userId]
                ]
            ]
        });

        const results = taskSearch.run().getRange({ start: 0, end: 1 });
        return results.length > 0;
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
});
