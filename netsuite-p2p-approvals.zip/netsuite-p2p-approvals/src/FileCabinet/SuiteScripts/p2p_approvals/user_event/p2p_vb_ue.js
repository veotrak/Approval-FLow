/**
 * @NApiVersion 2.1
 * @NScriptType UserEventScript
 * @NModuleScope Public
 * @description User Event script for Vendor Bill approval workflow with 3-way matching
 */
define([
    'N/record',
    'N/runtime',
    'N/ui/serverWidget',
    'N/search',
    '../lib/p2p_approval_engine',
    '../lib/p2p_matching_engine',
    '../lib/p2p_history_logger',
    '../constants/p2p_constants'
], function(record, runtime, serverWidget, search, approvalEngine, matchingEngine, historyLogger, constants) {

    const { APPROVAL_STATUS, BODY_FIELDS, TRANSACTION_TYPES, EXCEPTION_TYPE, MATCH_STATUS } = constants;

    /**
     * Before Load - Add UI elements and buttons
     */
    function beforeLoad(context) {
        const { type, form, newRecord } = context;

        if (type === context.UserEventType.VIEW || type === context.UserEventType.EDIT) {
            const approvalStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const recordId = newRecord.id;

            // Add approval status field group
            addApprovalStatusGroup(form, newRecord);

            // Add matching status field group
            addMatchingStatusGroup(form, newRecord);

            // Add approval history sublist
            addApprovalHistorySublist(form, recordId);

            // Add approval buttons based on status
            if (type === context.UserEventType.VIEW) {
                addApprovalButtons(form, newRecord, approvalStatus);
            }
        }

        if (type === context.UserEventType.CREATE) {
            // Set default status to Draft
            newRecord.setValue({
                fieldId: BODY_FIELDS.APPROVAL_STATUS,
                value: APPROVAL_STATUS.DRAFT
            });
            newRecord.setValue({
                fieldId: BODY_FIELDS.MATCH_STATUS,
                value: MATCH_STATUS.NOT_CHECKED
            });
        }
    }

    /**
     * Before Submit - Validate and perform matching checks
     */
    function beforeSubmit(context) {
        const { type, newRecord, oldRecord } = context;

        if (type === context.UserEventType.CREATE) {
            // Set initial status
            newRecord.setValue({
                fieldId: BODY_FIELDS.APPROVAL_STATUS,
                value: APPROVAL_STATUS.DRAFT
            });
            newRecord.setValue({
                fieldId: BODY_FIELDS.MATCH_STATUS,
                value: MATCH_STATUS.NOT_CHECKED
            });
        }

        if (type === context.UserEventType.EDIT) {
            const oldStatus = oldRecord?.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const newStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);

            // If approved bill is edited, may need re-approval
            if (oldStatus === APPROVAL_STATUS.APPROVED) {
                const oldAmount = parseFloat(oldRecord?.getValue('total')) || 0;
                const newAmount = parseFloat(newRecord.getValue('total')) || 0;

                if (newAmount > oldAmount) {
                    log.audit('VB amount increased after approval', {
                        id: newRecord.id,
                        oldAmount,
                        newAmount
                    });

                    // Reset to draft for re-approval
                    newRecord.setValue({
                        fieldId: BODY_FIELDS.APPROVAL_STATUS,
                        value: APPROVAL_STATUS.DRAFT
                    });
                    newRecord.setValue({
                        fieldId: BODY_FIELDS.MATCH_STATUS,
                        value: MATCH_STATUS.NOT_CHECKED
                    });
                }
            }
        }
    }

    /**
     * After Submit - Trigger matching and approval routing
     */
    function afterSubmit(context) {
        const { type, newRecord } = context;
        const recordId = newRecord.id;

        if (type === context.UserEventType.CREATE || type === context.UserEventType.EDIT) {
            const approvalStatus = newRecord.getValue(BODY_FIELDS.APPROVAL_STATUS);

            // Only process if in draft status
            if (approvalStatus === APPROVAL_STATUS.DRAFT) {
                // Perform 3-way matching first
                const matchResult = performMatching(recordId);

                // Route for approval
                routeForApproval(recordId, newRecord, matchResult);
            }
        }
    }

    /**
     * Perform 3-way matching validation
     */
    function performMatching(recordId) {
        try {
            const matchResult = matchingEngine.performMatchValidation({
                vendorBillId: recordId
            });

            // Update match status on record
            matchingEngine.updateMatchStatus(recordId, matchResult);

            log.debug('Matching completed', {
                recordId,
                status: matchResult.status,
                exceptions: matchResult.exceptions
            });

            return matchResult;

        } catch (e) {
            log.error('Error in matching', e);
            return {
                status: MATCH_STATUS.FAIL,
                exceptions: [EXCEPTION_TYPE.MISSING_PO],
                error: e.message
            };
        }
    }

    /**
     * Route VB for approval
     */
    function routeForApproval(recordId, vbRecord, matchResult) {
        try {
            // Reload record to get latest values
            const vb = record.load({
                type: 'vendorbill',
                id: recordId
            });

            const transactionData = {
                subsidiary: vb.getValue('subsidiary'),
                department: vb.getValue('department'),
                location: vb.getValue('location'),
                amount: parseFloat(vb.getValue('total')) || 0,
                currency: vb.getValue('currency'),
                vendor: vb.getText('entity'),
                vendorId: vb.getValue('entity'),
                tranId: vb.getValue('tranid'),
                tranDate: vb.getValue('trandate'),
                memo: vb.getValue('memo')
            };

            // Determine exception type for routing
            let exceptionType = null;
            if (matchResult.status === MATCH_STATUS.FAIL && matchResult.exceptions.length > 0) {
                exceptionType = matchResult.exceptions.length > 1 
                    ? EXCEPTION_TYPE.MULTIPLE 
                    : matchResult.exceptions[0];
            }

            const result = approvalEngine.routeForApproval({
                recordType: 'vendorbill',
                recordId: recordId,
                transactionData: transactionData,
                exceptionType: exceptionType
            });

            log.audit('VB routed for approval', {
                recordId,
                matchStatus: matchResult.status,
                exceptionType,
                result
            });

            return result;

        } catch (e) {
            log.error('Error routing VB for approval', e);
            throw e;
        }
    }

    /**
     * Add approval status field group to form
     */
    function addApprovalStatusGroup(form, record) {
        try {
            const statusGroup = form.addFieldGroup({
                id: 'custpage_approval_status_grp',
                label: 'Approval Status'
            });

            // Status display field
            const statusField = form.addField({
                id: 'custpage_approval_status_display',
                type: serverWidget.FieldType.TEXT,
                label: 'Status',
                container: 'custpage_approval_status_grp'
            });
            statusField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            const statusValue = record.getValue(BODY_FIELDS.APPROVAL_STATUS);
            const statusText = constants.APPROVAL_STATUS_TEXT[statusValue] || 'Unknown';
            statusField.defaultValue = statusText;

            // Current step display
            const currentStep = record.getValue(BODY_FIELDS.CURRENT_STEP);
            if (currentStep) {
                const stepField = form.addField({
                    id: 'custpage_current_step_display',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Current Step',
                    container: 'custpage_approval_status_grp'
                });
                stepField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });
                stepField.defaultValue = `Step ${currentStep}`;
            }

            // Current approver display
            const currentApprover = record.getText(BODY_FIELDS.CURRENT_APPROVER);
            if (currentApprover) {
                const approverField = form.addField({
                    id: 'custpage_current_approver_display',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Pending Approver',
                    container: 'custpage_approval_status_grp'
                });
                approverField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });
                approverField.defaultValue = currentApprover;
            }

            // Exception type display
            const exceptionType = record.getValue(BODY_FIELDS.EXCEPTION_TYPE);
            if (exceptionType) {
                const exceptionField = form.addField({
                    id: 'custpage_exception_display',
                    type: serverWidget.FieldType.TEXT,
                    label: 'Exception',
                    container: 'custpage_approval_status_grp'
                });
                exceptionField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });

                const exceptionLabels = {
                    [EXCEPTION_TYPE.MISSING_PO]: '⚠️ Missing PO Link',
                    [EXCEPTION_TYPE.VARIANCE_OVER_LIMIT]: '⚠️ Variance Over Limit',
                    [EXCEPTION_TYPE.MISSING_RECEIPT]: '⚠️ Missing Receipt',
                    [EXCEPTION_TYPE.MULTIPLE]: '⚠️ Multiple Exceptions'
                };

                exceptionField.defaultValue = exceptionLabels[exceptionType] || 'Unknown';
            }

        } catch (e) {
            log.error('Error adding approval status group', e);
        }
    }

    /**
     * Add matching status field group to form
     */
    function addMatchingStatusGroup(form, vbRecord) {
        try {
            const matchGroup = form.addFieldGroup({
                id: 'custpage_match_status_grp',
                label: '3-Way Match Status'
            });

            const matchStatus = vbRecord.getValue(BODY_FIELDS.MATCH_STATUS);

            // Overall match status
            const matchField = form.addField({
                id: 'custpage_match_status_display',
                type: serverWidget.FieldType.TEXT,
                label: 'Match Result',
                container: 'custpage_match_status_grp'
            });
            matchField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            const matchLabels = {
                [MATCH_STATUS.NOT_CHECKED]: '○ Not Checked',
                [MATCH_STATUS.PASS]: '✓ Pass',
                [MATCH_STATUS.FAIL]: '✗ Fail'
            };

            matchField.defaultValue = matchLabels[matchStatus] || 'Unknown';

            // If viewing, show detailed match info
            if (vbRecord.id && matchStatus !== MATCH_STATUS.NOT_CHECKED) {
                try {
                    const matchDetails = matchingEngine.getMatchDetailsForDisplay(vbRecord.id);

                    // PO Link status
                    const poField = form.addField({
                        id: 'custpage_po_link_status',
                        type: serverWidget.FieldType.TEXT,
                        label: 'PO Link',
                        container: 'custpage_match_status_grp'
                    });
                    poField.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    });
                    poField.defaultValue = `${matchDetails.poLink.status}: ${matchDetails.poLink.message}`;

                    // Receipt status
                    const receiptField = form.addField({
                        id: 'custpage_receipt_status',
                        type: serverWidget.FieldType.TEXT,
                        label: 'Receipt',
                        container: 'custpage_match_status_grp'
                    });
                    receiptField.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    });
                    receiptField.defaultValue = `${matchDetails.receipt.status}: ${matchDetails.receipt.message}`;

                    // Variance status
                    const varianceField = form.addField({
                        id: 'custpage_variance_status',
                        type: serverWidget.FieldType.TEXT,
                        label: 'Variance',
                        container: 'custpage_match_status_grp'
                    });
                    varianceField.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    });
                    varianceField.defaultValue = `${matchDetails.variance.status}: ${matchDetails.variance.message}`;

                } catch (e) {
                    log.debug('Could not load match details', e);
                }
            }

        } catch (e) {
            log.error('Error adding match status group', e);
        }
    }

    /**
     * Add approval history sublist
     */
    function addApprovalHistorySublist(form, recordId) {
        try {
            const historySublist = form.addSublist({
                id: 'custpage_approval_history',
                type: serverWidget.SublistType.LIST,
                label: 'Approval History'
            });

            historySublist.addField({
                id: 'custpage_ah_step',
                type: serverWidget.FieldType.TEXT,
                label: 'Step'
            });
            historySublist.addField({
                id: 'custpage_ah_action',
                type: serverWidget.FieldType.TEXT,
                label: 'Action'
            });
            historySublist.addField({
                id: 'custpage_ah_approver',
                type: serverWidget.FieldType.TEXT,
                label: 'By'
            });
            historySublist.addField({
                id: 'custpage_ah_timestamp',
                type: serverWidget.FieldType.TEXT,
                label: 'Date/Time'
            });
            historySublist.addField({
                id: 'custpage_ah_comment',
                type: serverWidget.FieldType.TEXT,
                label: 'Comment'
            });

            // Get history
            const history = historyLogger.getFormattedHistory(
                TRANSACTION_TYPES.VENDOR_BILL,
                recordId
            );

            history.forEach((h, index) => {
                historySublist.setSublistValue({
                    id: 'custpage_ah_step',
                    line: index,
                    value: h.step.toString()
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_action',
                    line: index,
                    value: h.action
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_approver',
                    line: index,
                    value: h.approver
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_timestamp',
                    line: index,
                    value: h.timestamp
                });
                historySublist.setSublistValue({
                    id: 'custpage_ah_comment',
                    line: index,
                    value: h.comment || ''
                });
            });

        } catch (e) {
            log.error('Error adding approval history sublist', e);
        }
    }

    /**
     * Add approval action buttons
     */
    function addApprovalButtons(form, record, approvalStatus) {
        const currentUser = runtime.getCurrentUser().id;
        const currentApprover = record.getValue(BODY_FIELDS.CURRENT_APPROVER);
        const recordId = record.id;

        try {
            // Submit for Approval button (for Draft status)
            if (approvalStatus === APPROVAL_STATUS.DRAFT) {
                form.addButton({
                    id: 'custpage_submit_approval',
                    label: 'Submit for Approval',
                    functionName: `submitForApproval(${recordId})`
                });

                // Re-check matching button
                form.addButton({
                    id: 'custpage_recheck_match',
                    label: 'Re-check Matching',
                    functionName: `recheckMatching(${recordId})`
                });
            }

            // Approve/Reject buttons (for current approver)
            if (approvalStatus === APPROVAL_STATUS.PENDING_APPROVAL) {
                // Check if current user is the approver
                const isApprover = isUserApprover(currentUser, recordId);

                if (isApprover) {
                    form.addButton({
                        id: 'custpage_approve',
                        label: 'Approve',
                        functionName: `approveRecord(${recordId})`
                    });

                    form.addButton({
                        id: 'custpage_reject',
                        label: 'Reject',
                        functionName: `rejectRecord(${recordId})`
                    });

                    // Exception override button (if user has permission)
                    const exceptionType = record.getValue(BODY_FIELDS.EXCEPTION_TYPE);
                    if (exceptionType && hasExceptionOverridePermission(currentUser)) {
                        form.addButton({
                            id: 'custpage_override_exception',
                            label: 'Approve with Exception',
                            functionName: `approveWithException(${recordId})`
                        });
                    }
                }
            }

            // Resubmit button (for Rejected status)
            if (approvalStatus === APPROVAL_STATUS.REJECTED) {
                const createdBy = record.getValue('createdby');
                if (currentUser == createdBy) {
                    form.addButton({
                        id: 'custpage_resubmit',
                        label: 'Resubmit for Approval',
                        functionName: `resubmitForApproval(${recordId})`
                    });
                }
            }

            // Add client script for button functions
            form.clientScriptModulePath = './p2p_vb_cs.js';

        } catch (e) {
            log.error('Error adding approval buttons', e);
        }
    }

    /**
     * Check if user is an approver for this record
     */
    function isUserApprover(userId, recordId) {
        const taskSearch = search.create({
            type: constants.RECORD_TYPES.APPROVAL_TASK,
            filters: [
                [constants.TASK_FIELDS.TRAN_TYPE, 'anyof', TRANSACTION_TYPES.VENDOR_BILL],
                'AND',
                [constants.TASK_FIELDS.TRAN_ID, 'equalto', recordId],
                'AND',
                [constants.TASK_FIELDS.STATUS, 'anyof', constants.TASK_STATUS.PENDING],
                'AND',
                [
                    [constants.TASK_FIELDS.APPROVER, 'anyof', userId],
                    'OR',
                    [constants.TASK_FIELDS.ACTING_APPROVER, 'anyof', userId]
                ]
            ]
        });

        const results = taskSearch.run().getRange({ start: 0, end: 1 });
        return results.length > 0;
    }

    /**
     * Check if user has exception override permission
     */
    function hasExceptionOverridePermission(userId) {
        // Check if user has a role that allows exception override
        // This would typically check a custom permission or specific roles
        const user = runtime.getCurrentUser();
        const role = user.role;

        // Example: Only Finance Director (role 3) and CFO can override
        const overrideRoles = [3, 4, 5]; // Update with actual role IDs
        return overrideRoles.includes(role);
    }

    return {
        beforeLoad: beforeLoad,
        beforeSubmit: beforeSubmit,
        afterSubmit: afterSubmit
    };
});
