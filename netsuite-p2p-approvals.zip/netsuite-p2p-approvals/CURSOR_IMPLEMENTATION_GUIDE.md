# NetSuite Procure-to-Pay Approval System - Cursor Implementation Guide

## Project Overview

Build a complete NetSuite approval workflow system for Purchase Orders and Vendor Bills with:
- Multi-dimensional approval matrix with wildcard support
- Multi-step serial/parallel approvals
- Delegation with date ranges
- Email approvals with secure tokens
- 3-way matching for Vendor Bills
- Full audit history
- AI-powered risk flagging

## Technology Stack

- NetSuite SuiteScript 2.1
- SuiteFlow (Workflows)
- SDF (SuiteCloud Development Framework)
- Custom Records for data model
- Suitelets for email approval handling
- Scheduled Scripts for reminders/escalation
- RESTlets for AI integration

---

## Project Structure

```
netsuite-p2p-approvals/
├── src/
│   ├── FileCabinet/
│   │   └── SuiteScripts/
│   │       └── p2p_approvals/
│   │           ├── constants/
│   │           │   └── p2p_constants.js
│   │           ├── lib/
│   │           │   ├── p2p_approval_engine.js
│   │           │   ├── p2p_delegation_manager.js
│   │           │   ├── p2p_matching_engine.js
│   │           │   ├── p2p_notification_manager.js
│   │           │   ├── p2p_history_logger.js
│   │           │   └── p2p_token_manager.js
│   │           ├── user_event/
│   │           │   ├── p2p_po_ue.js
│   │           │   └── p2p_vb_ue.js
│   │           ├── client/
│   │           │   ├── p2p_po_cs.js
│   │           │   └── p2p_vb_cs.js
│   │           ├── suitelet/
│   │           │   ├── p2p_email_approval_sl.js
│   │           │   ├── p2p_bulk_approval_sl.js
│   │           │   └── p2p_delegation_sl.js
│   │           ├── scheduled/
│   │           │   ├── p2p_reminder_ss.js
│   │           │   └── p2p_escalation_ss.js
│   │           ├── map_reduce/
│   │           │   └── p2p_bulk_process_mr.js
│   │           └── restlet/
│   │               └── p2p_ai_integration_rl.js
│   └── Objects/
│       ├── customrecord_p2p_approval_rule.xml
│       ├── customrecord_p2p_approval_step.xml
│       ├── customrecord_p2p_delegation.xml
│       ├── customrecord_p2p_approval_task.xml
│       ├── customrecord_p2p_approval_history.xml
│       ├── customrecord_p2p_dept_group.xml
│       ├── customrecord_p2p_dept_group_member.xml
│       ├── customrecord_p2p_loc_group.xml
│       ├── customrecord_p2p_loc_group_member.xml
│       ├── customlist_p2p_approval_status.xml
│       ├── customlist_p2p_approval_action.xml
│       ├── customlist_p2p_approver_type.xml
│       ├── customlist_p2p_execution_mode.xml
│       └── customlist_p2p_exception_type.xml
├── deploy.xml
├── manifest.xml
└── README.md
```

---

## Implementation Order

1. Custom Lists (dependencies for records)
2. Custom Records (data model)
3. Constants file
4. Library modules
5. User Event scripts
6. Client scripts
7. Suitelets
8. Scheduled scripts
9. Saved Searches
10. Workflows
11. Testing

---

## Quick Start Commands for Cursor

```bash
# Create project structure
mkdir -p src/FileCabinet/SuiteScripts/p2p_approvals/{constants,lib,user_event,client,suitelet,scheduled,map_reduce,restlet}
mkdir -p src/Objects

# Initialize SDF project
suitecloud project:create -i

# Deploy to sandbox
suitecloud project:deploy -p sandbox
```

---

## Custom Record Field Reference

### Approval Rule (customrecord_p2p_approval_rule)
| Field ID | Type | Required |
|----------|------|----------|
| custrecord_p2p_ar_tran_type | List | Yes |
| custrecord_p2p_ar_subsidiary | List | Yes |
| custrecord_p2p_ar_amount_from | Currency | Yes |
| custrecord_p2p_ar_amount_to | Currency | Yes |
| custrecord_p2p_ar_currency | List | No |
| custrecord_p2p_ar_department | List | No |
| custrecord_p2p_ar_location | List | No |
| custrecord_p2p_ar_dept_group | List | No |
| custrecord_p2p_ar_loc_group | List | No |
| custrecord_p2p_ar_priority | Integer | Yes |
| custrecord_p2p_ar_effective_from | Date | Yes |
| custrecord_p2p_ar_effective_to | Date | No |
| custrecord_p2p_ar_active | Checkbox | Yes |
| custrecord_p2p_ar_exc_no_po | Checkbox | No |
| custrecord_p2p_ar_exc_variance | Checkbox | No |
| custrecord_p2p_ar_exc_no_receipt | Checkbox | No |
| custrecord_p2p_ar_sla_hours | Integer | No |

### Approval Step (customrecord_p2p_approval_step)
| Field ID | Type | Required |
|----------|------|----------|
| custrecord_p2p_as_parent_rule | List | Yes |
| custrecord_p2p_as_sequence | Integer | Yes |
| custrecord_p2p_as_approver_type | List | Yes |
| custrecord_p2p_as_approver_role | List | No |
| custrecord_p2p_as_approver_employee | List | No |
| custrecord_p2p_as_execution_mode | List | Yes |
| custrecord_p2p_as_require_comment | Checkbox | No |

### Delegation (customrecord_p2p_delegation)
| Field ID | Type | Required |
|----------|------|----------|
| custrecord_p2p_del_original | List | Yes |
| custrecord_p2p_del_delegate | List | Yes |
| custrecord_p2p_del_start_date | Date | Yes |
| custrecord_p2p_del_end_date | Date | Yes |
| custrecord_p2p_del_subsidiary | List | No |
| custrecord_p2p_del_tran_type | List | No |
| custrecord_p2p_del_active | Checkbox | Yes |

### Approval Task (customrecord_p2p_approval_task)
| Field ID | Type | Required |
|----------|------|----------|
| custrecord_p2p_at_tran_type | List | Yes |
| custrecord_p2p_at_tran_id | Integer | Yes |
| custrecord_p2p_at_rule | List | Yes |
| custrecord_p2p_at_step | List | Yes |
| custrecord_p2p_at_sequence | Integer | Yes |
| custrecord_p2p_at_approver | List | Yes |
| custrecord_p2p_at_acting_approver | List | No |
| custrecord_p2p_at_status | List | Yes |
| custrecord_p2p_at_created | Datetime | Yes |
| custrecord_p2p_at_completed | Datetime | No |
| custrecord_p2p_at_token | Text | No |
| custrecord_p2p_at_token_expiry | Datetime | No |
| custrecord_p2p_at_reminder_count | Integer | No |
| custrecord_p2p_at_escalated | Checkbox | No |

### Approval History (customrecord_p2p_approval_history)
| Field ID | Type | Required |
|----------|------|----------|
| custrecord_p2p_ah_tran_type | List | Yes |
| custrecord_p2p_ah_tran_id | Integer | Yes |
| custrecord_p2p_ah_step_sequence | Integer | Yes |
| custrecord_p2p_ah_approver | List | Yes |
| custrecord_p2p_ah_acting_approver | List | No |
| custrecord_p2p_ah_action | List | Yes |
| custrecord_p2p_ah_timestamp | Datetime | Yes |
| custrecord_p2p_ah_comment | Textarea | No |
| custrecord_p2p_ah_ip_address | Text | No |
| custrecord_p2p_ah_method | List | No |

---

## Transaction Custom Fields

Add these fields to Purchase Order and Vendor Bill:

| Field ID | Type | Applies To |
|----------|------|------------|
| custbody_p2p_approval_status | List | PO, VB |
| custbody_p2p_current_step | Integer | PO, VB |
| custbody_p2p_current_approver | List | PO, VB |
| custbody_p2p_approval_rule | List | PO, VB |
| custbody_p2p_exception_type | List | VB |
| custbody_p2p_match_status | List | VB |
| custbody_p2p_ai_risk_score | Decimal | PO, VB |
| custbody_p2p_ai_risk_flags | Textarea | PO, VB |

---

## Key Integration Points

### Email Approval URL Pattern
```
https://{account}.app.netsuite.com/app/site/hosting/scriptlet.nl?script=customscript_p2p_email_approval_sl&deploy=customdeploy_p2p_email_approval&token={token}&action={approve|reject}
```

### AI Integration Endpoint
```
https://{account}.restlets.api.netsuite.com/app/site/hosting/restlet.nl?script=customscript_p2p_ai_rl&deploy=customdeploy_p2p_ai
```

---

## Testing Checklist

- [ ] Approval Rule CRUD operations
- [ ] Approval Step configuration
- [ ] Rule matching algorithm (all specificity levels)
- [ ] Delegation routing
- [ ] PO submission flow
- [ ] VB submission flow
- [ ] 3-way matching (pass/fail scenarios)
- [ ] Email approval (approve/reject)
- [ ] Token expiry handling
- [ ] Reminder emails (24h, 48h)
- [ ] Escalation (72h)
- [ ] Bulk approval
- [ ] History logging
- [ ] Segregation of duties checks
- [ ] AI risk flagging
