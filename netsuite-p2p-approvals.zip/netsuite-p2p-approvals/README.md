# NetSuite P2P Approval System

A comprehensive Procure-to-Pay (P2P) approval workflow system for NetSuite with Purchase Order and Vendor Bill approvals, 3-way matching, delegation, and email approvals.

## Features

### Approval Matrix
- Multi-dimensional routing by subsidiary, department, location, amount
- Support for department and location groups (wildcards)
- Priority-based rule matching (most specific wins)
- Multi-step serial and parallel approvals
- Effective date ranges for rules

### Delegation
- Date-ranged delegation support
- Scope by subsidiary and transaction type
- Full audit trail showing original and acting approver
- Maximum 30-day delegation periods

### Vendor Bill 3-Way Matching
- PO link validation (required over $1,000)
- Receipt validation for inventory items
- Price variance check (5% or $500 tolerance)
- Quantity variance check (zero tolerance)
- Exception routing for failed matches

### Notifications
- Email approval with secure tokens
- One-click approve/reject from email
- Automated reminders (24h, 48h)
- Escalation to manager (72h)
- Approved/rejected notifications to requestor

### Security
- Token-based email approvals (72h expiry)
- Segregation of duties enforcement
- Role-based approval limits
- IP address logging for email approvals

## Installation

### Prerequisites
- NetSuite account with SuiteCloud Development Framework
- Administrator role or equivalent permissions
- SuiteScript 2.1 enabled

### Deployment Steps

1. **Clone the repository**
```bash
git clone <repository-url>
cd netsuite-p2p-approvals
```

2. **Configure SDF**
```bash
suitecloud account:setup
```

3. **Deploy to sandbox**
```bash
suitecloud project:deploy -p sandbox
```

4. **Verify deployment**
- Check custom records are created
- Verify script deployments are active
- Test with a sample PO

## Configuration

### 1. Create Department Groups
Navigate to: Customization > Lists, Records & Fields > Record Types > P2P Department Group

Create groups like:
- Corporate (Finance, HR)
- Commercial (Sales, Marketing)
- Technical (IT, Operations)

### 2. Create Location Groups
Navigate to: Customization > Lists, Records & Fields > Record Types > P2P Location Group

Create groups like:
- North America (HQ, West, East)
- EMEA (London, Paris)
- APAC (Singapore, Tokyo)

### 3. Create Approval Rules
Navigate to: Customization > Lists, Records & Fields > Record Types > P2P Approval Rule

Example rule:
- Transaction Type: Purchase Order
- Subsidiary: US Operations
- Amount From: 0
- Amount To: 10000
- Department Group: Corporate
- Priority: 10
- Active: Yes

### 4. Create Approval Steps
For each rule, create steps:
- Step 1: Department Manager (Serial)
- Step 2: Finance Director (Serial, for higher amounts)
- Step 3: CFO (Serial, for highest amounts)

### 5. Configure Scheduled Scripts
- P2P Reminder: Every 4 hours
- P2P Escalation: Every 4 hours

## Usage

### Submitting for Approval
1. Create/edit a Purchase Order or Vendor Bill
2. Click "Submit for Approval"
3. System routes to appropriate approvers

### Approving via NetSuite
1. Open the transaction
2. Click "Approve" or "Reject"
3. Add comment if required
4. Action is logged

### Approving via Email
1. Receive approval request email
2. Click "Approve" or "Reject" button
3. Confirm action on web page
4. Done!

### Setting Up Delegation
1. Navigate to: P2P Delegation Suitelet
2. Select delegate employee
3. Set date range
4. Optionally limit by subsidiary or transaction type
5. Save

## Technical Architecture

### Scripts
| Script | Type | Purpose |
|--------|------|---------|
| p2p_po_ue.js | User Event | PO workflow triggers |
| p2p_vb_ue.js | User Event | VB workflow with matching |
| p2p_po_cs.js | Client | PO UI buttons |
| p2p_vb_cs.js | Client | VB UI buttons |
| p2p_email_approval_sl.js | Suitelet | Email approval handler |
| p2p_bulk_approval_sl.js | Suitelet | Bulk approval UI |
| p2p_reminder_ss.js | Scheduled | Send reminders |
| p2p_escalation_ss.js | Scheduled | Escalate overdue |

### Libraries
| Module | Purpose |
|--------|---------|
| p2p_approval_engine.js | Core routing logic |
| p2p_delegation_manager.js | Delegation handling |
| p2p_matching_engine.js | 3-way matching |
| p2p_notification_manager.js | Email notifications |
| p2p_history_logger.js | Audit trail |
| p2p_token_manager.js | Secure tokens |

### Custom Records
| Record | Purpose |
|--------|---------|
| P2P Approval Rule | Routing configuration |
| P2P Approval Step | Steps within rules |
| P2P Delegation | Delegation settings |
| P2P Approval Task | Pending tasks |
| P2P Approval History | Audit log |
| P2P Dept/Loc Groups | Groupings |

## Saved Searches

- **Pending Approvals by Approver**: Dashboard view of pending work
- **Pending Approvals by Age**: Track aging approvals
- **Approval Bottlenecks**: Identify slow steps
- **Matching Exceptions**: Monitor VB exceptions
- **Approvals by Month**: Volume reporting

## Troubleshooting

### Common Issues

**Token Expired**
- Tokens expire after 72 hours
- User must approve via NetSuite UI
- Or request new approval email

**No Matching Rule**
- Check rule effective dates
- Verify subsidiary matches
- Check amount ranges
- Review department/location mappings

**Delegation Not Working**
- Verify delegation is active
- Check date range includes today
- Confirm subsidiary/transaction scope

### Logging
All scripts log to the Script Execution Log:
- DEBUG: Detailed processing info
- AUDIT: Key actions (approvals, escalations)
- ERROR: Failures and exceptions

## Support

For issues or questions:
1. Check execution logs for errors
2. Review configuration settings
3. Test with simple rule first
4. Contact system administrator

## License

Proprietary - Internal Use Only

## Version History

- **1.0.0** - Initial release
  - Core approval routing
  - Email approvals
  - 3-way matching
  - Delegation support
  - Reminders and escalation
